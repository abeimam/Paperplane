"""Google Fonts catalog and lazy English/Latin font download support.

The editor does not bundle 1,000+ font binaries. It keeps a cached Google Fonts
metadata catalog and downloads/converts only the face the user actually selects.
This keeps startup fast and avoids repeatedly downloading fonts.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

CATALOG_URL = os.getenv("GOOGLE_FONTS_METADATA_URL", "https://fonts.google.com/metadata/fonts")
CSS_URL = "https://fonts.googleapis.com/css2?family={family}:ital,wght@0,400;0,700;1,400;1,700&subset=latin"
CACHE_ROOT = Path(os.getenv("GOOGLE_FONT_CACHE", "/data/google-fonts"))
CATALOG_PATH = CACHE_ROOT / "catalog.json"
CATALOG_TTL = int(os.getenv("GOOGLE_FONTS_CATALOG_TTL", str(7 * 24 * 3600)))
TIMEOUT = float(os.getenv("GOOGLE_FONTS_TIMEOUT", "15"))

# A small emergency seed means the picker still works if the server starts
# without network access for the first time. A live metadata refresh replaces it
# with the complete current Google Fonts Latin catalog (currently well over 1,000).
SEED_FAMILIES = [
    "Roboto", "Open Sans", "Lato", "Montserrat", "Poppins", "Inter", "Oswald",
    "Raleway", "Nunito", "Merriweather", "Playfair Display", "Source Sans 3",
    "Source Serif 4", "Noto Sans", "Noto Serif", "Ubuntu", "Rubik", "Work Sans",
    "DM Sans", "Manrope", "Outfit", "Quicksand", "Fira Sans", "Fira Code",
    "PT Sans", "PT Serif", "Libre Baskerville", "Libre Franklin", "Bebas Neue",
    "Barlow", "Cabin", "Karla", "Mulish", "Josefin Sans", "Archivo", "Abel",
    "Anton", "Bitter", "Caveat", "Comfortaa", "Cormorant Garamond", "Crimson Text",
    "Dancing Script", "Exo 2", "Heebo", "IBM Plex Sans", "IBM Plex Serif", "Inconsolata",
    "Jost", "Kanit", "Lexend", "Merriweather Sans", "Nanum Gothic", "Nunito Sans",
    "Pacifico", "Permanent Marker", "Roboto Condensed", "Roboto Slab", "Sora", "Space Grotesk",
    "Space Mono", "Spectral", "Titillium Web", "Varela Round", "Vollkorn", "Yanone Kaffeesatz",
]


def _english_family_names(payload: dict) -> list[str]:
    entries = payload.get("familyMetadataList") or payload.get("families") or []
    names: list[str] = []
    for entry in entries:
        if isinstance(entry, str):
            name, subsets = entry, ["latin"]
        elif isinstance(entry, dict):
            name = str(entry.get("family") or entry.get("name") or "").strip()
            subsets = entry.get("subsets") or []
        else:
            continue
        # Google metadata's latin subset is the useful definition here: it
        # covers English/Latin text without restricting the font to ASCII only.
        if name and ("latin" in subsets or not subsets):
            names.append(name)
    return sorted(set(names), key=str.casefold)


def _read_catalog() -> list[str]:
    try:
        if CATALOG_PATH.is_file() and time.time() - CATALOG_PATH.stat().st_mtime < CATALOG_TTL:
            payload = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
            families = payload.get("families", [])
            if len(families) >= 1000:
                return families
    except Exception:
        pass
    return list(SEED_FAMILIES)


def refresh_catalog(force: bool = False) -> list[str]:
    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    if not force:
        cached = _read_catalog()
        if len(cached) >= 1000 or (CATALOG_PATH.is_file() and time.time() - CATALOG_PATH.stat().st_mtime < CATALOG_TTL):
            return cached
    try:
        request = Request(CATALOG_URL, headers={"User-Agent": "Paperplane-PDF-Editor/1.0"})
        with urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read().decode("utf-8")
            if raw.startswith(")]}'"):
                raw = raw[4:]
            payload = json.loads(raw)
        families = _english_family_names(payload)
        if families:
            CATALOG_PATH.write_text(json.dumps({"version": 1, "families": families}, ensure_ascii=False), encoding="utf-8")
            return families
    except Exception:
        pass
    return _read_catalog()


def catalog() -> list[str]:
    # Try a refresh when the cache is absent/stale. The endpoint remains fast
    # because a valid cache is returned immediately.
    return refresh_catalog(False)


def _safe_family(family: str) -> str:
    if not family or len(family) > 120 or any(ord(c) < 32 for c in family):
        raise ValueError("Invalid Google font family")
    return family


def _css_source_urls(family: str, bold: bool, italic: bool) -> list[str]:
    family = _safe_family(family)
    # Ask Google for the requested style first; its CSS response can contain
    # multiple unicode-range blocks. We only need the Latin block.
    query = family.replace(" ", "+")
    weight = 700 if bold else 400
    if italic:
        css_url = f"https://fonts.googleapis.com/css2?family={quote(family)}:ital,wght@1,{weight}&subset=latin"
    else:
        css_url = f"https://fonts.googleapis.com/css2?family={quote(family)}:wght@{weight}&subset=latin"
    request = Request(css_url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=TIMEOUT) as response:
        css = response.read().decode("utf-8", errors="replace")
    urls = re.findall(r"url\((https?://[^)]+)\)", css)
    # Prefer URLs in blocks whose comment contains latin/latin-ext. Google
    # normally places the Latin block last, so preserve response order and
    # de-duplicate.
    return list(dict.fromkeys(urls))


def ensure_font(family: str, bold: bool = False, italic: bool = False) -> Path | None:
    """Return a cached TTF for a Google Latin font face, downloading lazily."""
    if family not in set(catalog()):
        return None
    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", family.casefold()).strip("-")
    target = CACHE_ROOT / f"{slug}-{int(bool(bold))}{int(bool(italic))}.ttf"
    if target.is_file() and target.stat().st_size > 1000:
        return target
    try:
        urls = _css_source_urls(family, bold, italic)
        if not urls:
            return None
        from fontTools.ttLib import TTFont
        import io
        # Prefer the last URL, which is normally the Latin/Latin-ext block in
        # Google Fonts CSS. Try every URL in case a provider changes ordering.
        for url in reversed(urls):
            try:
                request = Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urlopen(request, timeout=TIMEOUT) as response:
                    data = response.read()
                font = TTFont(io.BytesIO(data))
                font.flavor = None
                temp = target.with_suffix(".tmp")
                font.save(str(temp))
                temp.replace(target)
                if target.is_file() and target.stat().st_size > 1000:
                    return target
            except Exception:
                continue
    except Exception:
        return None
    return None
