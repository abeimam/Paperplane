# Build / install policy

## Default: never replace an installed dependency
The installer checks the current environment first. If a Python distribution is already installed, it is **skipped even if its version differs**. This prevents a download/reinstall just because `requirements.txt` has a different pinned version.

APT packages are likewise skipped when already installed. Package indexes are refreshed only when no usable local index exists or installation reports stale metadata.

Set `FORCE_INSTALL=1` only when you explicitly want replacement/reinstallation.

## Docker
A Docker image is an isolated environment; host-installed Python/OS packages cannot be used inside it. The Dockerfile therefore checks its own image layer and uses persistent BuildKit APT/PyPI caches. Rebuilding the same image reuses cached artifacts instead of downloading them again.

If the requirement is **zero dependency downloads**, run the host installation mode (`./scripts/install.sh`) on the machine where the dependencies are already installed and start the app from that environment. A brand-new Docker image cannot inherit arbitrary host packages.
