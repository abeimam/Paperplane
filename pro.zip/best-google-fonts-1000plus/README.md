# Local PDF Editor

Paperplane is a local-first PDF text editor. It extracts selectable PDF text, analyzes page structure, reads scanned pages with local OCR, and exports an edited PDF.

## Start with Docker

Requirements: Docker Engine or Docker Desktop with Docker Compose, plus internet access for the initial image build and model downloads.

```bash
PDF_EDITOR_PORT=8001 docker compose up --build -d
```

Open <http://localhost:8001>. If port 8001 is already used, set `PDF_EDITOR_PORT` to another available local port and open that address.

Select **Open PDF**, choose a page, and select **Analyze page**. OCR and layout weights download on first use and are cached locally. Each page is checked with local OCR, including mixed pages where only some content is selectable; duplicate OCR boxes over native PDF text are filtered out. **Edit mode** filters the item list to all items, text, or images. **＋ Text** places editable text where you click. **＋ Image** uploads a PNG, JPEG, or WebP; click the page to place it, then drag it or use the corner handle/size fields to resize it. The aspect lock keeps image proportions. Turn on **Add behind page content** to insert new content below existing PDF objects.

Use **Grid** to show half-inch alignment guides over the page. **Originals** shows the former outline of text or images after you move, resize, or delete them. A click selects without moving or re-rendering an object. Drag text or images to move them, or use **Position and size** for exact placement. Select several objects to move or delete them together. Use page-area filters and selection-scoped Find & Replace for larger edits, then choose **Export PDF**.

The page itself updates as you type, change font/size/color, delete, resize, or drag an object. A click only selects an object; dragging starts after a deliberate pointer movement, so normal pointer jitter cannot move and re-render the text. A **Live preview · matches PDF output** badge appears after the backend has rendered the pending changes with the same PDF editing pipeline used by Export PDF. This takes a short moment after each change; the previous rendered page remains visible while the next one is being prepared.

The app listens on localhost only. Useful commands:

```bash
docker compose logs -f pdf-editor  # follow startup and model messages
docker compose down               # stop the app
```

Uploaded PDFs and generated document assets are stored only for the currently open document under `./data/<document-id>`. Loading a new PDF transactionally deletes the previous document folder; restarting the server also purges any leftover uploaded-document folders. Reusable OCR/FontID model caches use named Docker volumes and are not document data. Removing the volumes also removes cached model weights: `docker compose down -v`.

## Run without Docker (Linux x86-64 CPU)

Use the idempotent installer so the machine is checked before anything is installed:

```bash
./scripts/install.sh
```

It checks APT packages, the existing `.venv`, PaddlePaddle, PyTorch, and every pinned requirement. Matching versions are skipped. Python packages use a persistent cache at `~/.cache/pdf-editor/pip`, so previously downloaded wheels are reused. Set `FORCE_INSTALL=1` only when you deliberately want to reinstall.

Then start the server:

```bash
PADDLE_PDX_CACHE_HOME=./data/model-cache DATA_DIR=./data uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Then open <http://localhost:8000>. For other CPU architectures or GPU setup, install the matching PaddlePaddle wheel from the [official installation guide](https://www.paddlepaddle.org.cn/documentation/docs/en/install/pip/linux-pip_en.html).

## Rebuild without redownloading

For Docker, use a recent Docker with BuildKit:

```bash
docker compose build
docker compose up -d
```

The Docker build checks packages inside the image and uses persistent BuildKit caches for APT archives/package lists and PyPI wheels. A Docker container cannot reuse packages installed on the host because the filesystems are isolated; however, repeated builds reuse the cached downloads instead of fetching the same artifacts again. OCR, layout, and FontID model caches are persistent Docker volumes and are reused across normal container recreation.

See `BUILD.md` for the exact caching and reinstall behavior.

## Document retention and privacy

This is intentionally a single-document editor. The server does not keep a library of uploaded PDFs. A newly uploaded PDF is fully validated and prepared first; once it succeeds, the previous document folder is deleted and only the new document remains. If a process restarts, uploaded-document folders are purged during application startup. Preview images, extracted PDF fonts, inserted images, `document.json`, and exported `edited.pdf` files live inside that same temporary document folder and are removed with it.

The browser also releases its previous live-preview blob when switching documents. Model and font caches may remain because they contain reusable application resources rather than user PDFs.

## Models

- **PP-OCRv6** handles text detection and recognition on scanned pages. PaddleOCR 3.7 uses its PP-OCRv6 medium model by default; PP-OCRv6 medium recognition supports 50 languages according to the current model guide.
- **PP-DocLayout-L** detects page areas such as headings, paragraphs, figures, and other content blocks. Native PDF text boxes are associated with detected regions.
- **FontID** (`issai/FontID`, Apache-2.0) supplies a scanned text crop's closest family category and style. Its SigLIP2 model has 75 font-family labels, is pinned to a fixed revision, and downloads locally on first page analysis. Because this is a closed-set classifier, its result is only a hint.
- **Open-set font matching** renders each OCR-recognized string in supported candidate faces and compares the glyph shape and word proportions against the scanned crop. The catalog includes fonts embedded anywhere in the current PDF plus installed open faces from DejaVu, Noto, Liberation, Lato, Carlito, and URW. An embedded font found in the same PDF receives a small ranking prior; the UI also shows the raw glyph-match score so it does not imply certainty.
- Native text shows the font face and point size recorded in PDF text metadata; when an embedded font can be extracted and supports every replacement character, export reuses it. Moving text preserves its original PDF appearance. For scanned text, there is no encoded source font to recover: the editor measures visible glyph pixels, fits their width and height to candidate font metrics, and samples ink color from the page. The inspector labels these values as estimates. Multilingual scripts outside direct shape matching continue through PDF-font evidence, FontID where supported, and a labeled script-aware fallback. Deleting or shortening text compacts later text in the same detected line and aligned paragraph flow using recorded glyph advances where available.
- Models run locally on CPU. OCR, layout, and FontID weights download on first use and remain in Docker's named model-cache volumes. Table and background layer scans are omitted from the normal analysis workflow. No document text is sent to a hosted model API.

PaddleOCR code is distributed under Apache-2.0. Review the upstream project and model notices for the terms attached to the exact weights you use.

## What this starter supports

- PDF upload, page preview and page navigation.
- Layout and text analysis, region filtering, text search, multi-select, selection-scoped find/replace, and undo/redo.
- Text changes, deletion/restoration, same-line and aligned paragraph compaction after removals, color, style, installed-font selection, size, shape-preserving drag movement, and numeric placement controls.
- Image selection, movement, deletion/restoration, proportional resizing, and numeric placement controls.
- New text insertion, local image upload and placement, drag resizing with an aspect lock, exact geometry controls, and live PDF preview for inserted objects.
- PDF images move by rebuilding the image object from the original extracted asset instead of rasterizing it during the move.
- Alignment grid and original-position overlays can be shown or hidden from the canvas toolbar.
- The searchable font picker filters embedded font matches, visual candidates, and installed font families. Native PDF font metadata is shown separately from estimated scanned-text matches.
- Live PDF page preview while editing: the backend redraws changed text, images, styles, and placement using the export pipeline before export. This avoids browser-font approximations; embedded source fonts and installed open-font fallbacks are rendered by the PDF engine.
- Local PDF export with text replacement and deletion.

## Important limits

This is a local single-user editor and should not be exposed directly to the internet. It has no authentication, database, job queue, malware scanning, or cloud storage. PDF uploads are limited to 25 MB and 20 pages; added images are limited to 12 MB and 40 megapixels. Changed text is redacted using a sampled nearby page color before replacement text is inserted; this works best on flat backgrounds. Complex artwork or gradients, forms, annotations, unusual embedded fonts, rotated pages, handwriting, and difficult scans can still need manual correction. OCR's font family and size are estimates because the original typeface is not encoded in a scan; font selection shows the closest visual match and the face actually used for rendering. Review detections and exported pages, and keep the original PDF.

## References

- [PaddleOCR source and Apache-2.0 license](https://github.com/PaddlePaddle/PaddleOCR)
- [PaddleOCR OCR pipeline and PP-OCRv6 models](https://www.paddleocr.ai/main/en/version3.x/pipeline_usage/OCR.html)
- [PaddleOCR layout detection models and API](https://www.paddleocr.ai/main/en/version3.x/module_usage/layout_detection.html)
- [PaddlePaddle CPU installation guide](https://www.paddlepaddle.org.cn/documentation/docs/en/install/pip/linux-pip_en.html)
- [FontID model card, supported labels, and Apache-2.0 license](https://huggingface.co/issai/FontID)
- [PyTorch CPU installation guide](https://pytorch.org/get-started/locally/)

### Font accuracy and rotation

Native/selectable PDF text now treats the font face recorded in the PDF content stream as authoritative. The inspector shows the exact recorded face, preserves an extracted embedded font when replacement characters are supported, uses the canonical built-in face for standard PDF fonts, and refuses to silently substitute a different face when an exact native font is unavailable or lacks the replacement glyphs. Scanned text remains explicitly labeled as a visual estimate because a raster image does not encode its original font.

Text objects also carry a rotation angle (0–359°). The inspector provides an exact angle field plus 0°, 90°, 180°, and 270° presets. Rotation is applied consistently to the canvas overlay, live PDF preview, vector export, and OCR-backed raster text edits.

### Expanded PDF font coverage
The editor now resolves legacy PostScript/Type 1 PDF fonts by exact PostScript filename in addition to TTF/OTF/TTC fonts. A bundled Computer Modern Type 1 pack covers classic TeX faces such as `CMBX12`, `CMR12`, `CMSS10`, and related variants. This is used before family-based fontconfig matching, so unembedded classic TeX fonts can still be reused exactly when their standard font program is available in the bundled pack.

When a PDF references a font for which the file is genuinely absent from both the PDF and the local/bundled font pool, replacement editing falls back to a compatible available face rather than blocking export. A PDF cannot recreate an arbitrary missing font program when the original font was never embedded.

## Idempotent installation / build

The project does not intentionally reinstall an existing matching environment. For Linux hosts, run:

```bash
./scripts/install.sh
```

The installer checks APT packages and exact Python distribution versions first and prints `[skip]` for matches. It creates/reuses `.venv` rather than deleting it. Set `FORCE_INSTALL=1` only when you explicitly want a reinstall.

Docker builds also avoid upgrading pip and conditionally install pinned Python distributions. Docker's layer cache reuses unchanged system-package and dependency layers. Model/font caches are persistent Docker volumes and are not downloaded again when already present.

### Google Fonts catalog

The font picker uses the **Google Fonts Latin subset** rather than a small hard-coded system-font list. On a network-enabled deployment it refreshes the current Google Fonts metadata and exposes the complete Latin catalog (well over 1,000 families). Fonts are **lazy downloaded only when selected**, converted from Google WOFF2 to cached TTF, and reused on later edits. The catalog and font binaries live outside the per-document directory, so opening a new PDF does not delete reusable Google font resources.

If the deployment is temporarily offline, a small built-in seed keeps the picker usable; once Google Fonts is reachable, the complete catalog is cached. `/api/fonts/status` reports the current catalog count.

