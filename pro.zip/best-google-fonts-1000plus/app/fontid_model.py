"""Small FontID inference wrapper based on issai/FontID (Apache-2.0).

The upstream model is a SigLIP2 visual encoder with independent font, language,
color and style heads. Keep this implementation local so loading the weights
does not execute Python code downloaded from a model repository.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
from safetensors.torch import load_file
from torch import nn
from transformers.models.siglip2.modeling_siglip2 import Siglip2VisionConfig, Siglip2VisionTransformer


class FontIDModel(nn.Module):
    def __init__(self, vision_config: dict[str, Any], num_classes: dict[str, int], heads: list[str]):
        super().__init__()
        self.heads = list(heads)
        config = Siglip2VisionConfig(**vision_config)
        config._attn_implementation = "eager"
        self.vision = Siglip2VisionTransformer(config)
        self.dropout = nn.Dropout(0.2)

        def make_head(class_count: int) -> nn.Sequential:
            return nn.Sequential(
                nn.Linear(config.hidden_size, 512),
                nn.LayerNorm(512),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(512, class_count),
            )

        self.head_modules = nn.ModuleDict({head: make_head(num_classes[head]) for head in self.heads})

    def forward(self, pixel_values: Any, pixel_attention_mask: Any, spatial_shapes: Any) -> dict[str, Any]:
        features = self.vision(
            pixel_values=pixel_values,
            attention_mask=pixel_attention_mask,
            spatial_shapes=spatial_shapes,
        )
        pooled = self.dropout(features.pooler_output)
        return {head: self.head_modules[head](pooled) for head in self.heads}

    @classmethod
    def from_pretrained(cls, directory: str | Path) -> "FontIDModel":
        directory = Path(directory)
        config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
        model = cls(config["vision_config"], config["num_classes"], config.get("heads", ["font", "lang", "color", "style"]))
        weights = load_file(str(directory / "model.safetensors"), device="cpu")
        model.load_state_dict(weights, strict=True)
        return model.eval()
