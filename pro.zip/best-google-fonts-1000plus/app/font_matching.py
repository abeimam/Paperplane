"""Open-set font matching for OCR text, using PDF fonts and rendered glyph shapes.

Font classifiers return closed-set labels. This module instead builds a candidate
catalog from the current PDF and installed fonts, then ranks candidates by how
closely the known OCR string renders against the observed glyph crop.
"""
from __future__ import annotations

import math
import re
import subprocess
from functools import lru_cache
from pathlib import Path
from typing import Any

import pymupdf as fitz


def _style_flags(style: str) -> tuple[bool, bool]:
    lowered = style.lower()
    return any(word in lowered for word in ("bold", "black", "heavy", "demi")), any(
        word in lowered for word in ("italic", "oblique")
    )


def build_font_catalog(document_objects: list[dict[str, Any]], folder: Path) -> list[dict[str, Any]]:
    """Return de-duplicated document-embedded fonts and installed open fonts."""
    catalog: list[dict[str, Any]] = []
    seen: set[tuple[str, bool, bool, str]] = set()

    def add(path: Path, family: str, bold: bool, italic: bool, source: str, asset_id: str | None = None) -> None:
        if path.suffix.lower() not in {".ttf", ".otf", ".ttc", ".pfb", ".pfa"} or not path.is_file():
            return
        try:
            font = fitz.Font(fontfile=str(path))
            ps_name = font.name or path.stem
        except Exception:
            return
        family = (family or ps_name).strip().split(",")[0]
        key = (re.sub(r"[^a-z0-9]", "", family.lower()), bold, italic, source)
        if not key[0] or key in seen:
            return
        seen.add(key)
        catalog.append({"family": family, "path": path, "bold": bold, "italic": italic,
                        "source": source, "assetId": asset_id, "postscript": ps_name, "_font": font})

    # Native PDF text is an exact source of font metadata; its embedded file is
    # also usable for scan text on other pages in the same document.
    for item in document_objects:
        asset_id, extension = item.get("fontAsset"), item.get("fontAssetExt")
        if not isinstance(asset_id, str) or not re.fullmatch(r"[0-9a-f]{32}", asset_id):
            continue
        if extension not in {"ttf", "otf", "ttc", "pfb", "pfa"}:
            continue
        add(folder / "fonts" / f"{asset_id}.{extension}", str(item.get("font", "")),
            bool(item.get("bold")), bool(item.get("italic")), "document", asset_id)

    # Keep broad coverage while avoiding a long list of duplicate aliases and
    # CJK collection faces. Rendering those fonts remains available through the
    # existing script-aware fallback when the text is outside Latin/Cyrillic.
    if not __import__("shutil").which("fc-list"):
        return catalog
    try:
        result = subprocess.run(
            ["fc-list", "--format=%{family}\t%{style}\t%{file}\n"],
            capture_output=True, text=True, check=False, timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return catalog
    if result.returncode != 0:
        return catalog
    installed: list[dict[str, Any]] = []
    for line in result.stdout.splitlines():
        fields = line.split("\t")
        if len(fields) != 3:
            continue
        family, style, filename = fields
        path = Path(filename)
        bold, italic = _style_flags(style)
        if path.suffix.lower() not in {".ttf", ".otf"}:
            continue
        # Prefer regular and common text faces; decorative/variable faces can
        # still enter through the PDF itself or a FontID suggestion.
        family = family.split(",")[0].strip()
        installed.append({"path": path, "family": family, "bold": bold, "italic": italic,
                          "source": "installed", "assetId": None})
    installed.sort(key=lambda entry: (entry["bold"] or entry["italic"], entry["family"].lower()))
    for entry in installed:
        add(entry["path"], entry["family"], entry["bold"], entry["italic"], "installed")
        if len(catalog) >= 220:
            break
    return catalog


def _supports(candidate: dict[str, Any], text: str) -> bool:
    try:
        font = candidate.get("_font") or fitz.Font(fontfile=str(candidate["path"]))
        return all(character.isspace() or font.has_glyph(ord(character)) for character in text)
    except Exception:
        return False


def compatible_document_fonts(text: str, catalog: list[dict[str, Any]], limit: int = 3) -> list[dict[str, Any]]:
    """Offer embedded PDF faces that contain the OCR string's glyphs."""
    candidates: list[dict[str, Any]] = []
    seen: set[tuple[str, bool, bool]] = set()
    for entry in catalog:
        if entry["source"] != "document" or not _supports(entry, text):
            continue
        key = (re.sub(r"[^a-z0-9]", "", entry["family"].lower()), entry["bold"], entry["italic"])
        if key in seen:
            continue
        seen.add(key)
        candidates.append({"family": entry["family"], "value": f"document:{entry['assetId']}",
                           "confidence": None, "visualScore": None, "bold": entry["bold"],
                           "italic": entry["italic"], "source": "document", "assetId": entry["assetId"]})
        if len(candidates) >= limit:
            break
    return candidates


def _binary_crop(image: Any, box: tuple[int, int, int, int]) -> Any | None:
    import numpy as np

    left, top, right, bottom = box
    left = max(0, min(image.width, left)); right = max(left, min(image.width, right))
    top = max(0, min(image.height, top)); bottom = max(top, min(image.height, bottom))
    if right - left < 3 or bottom - top < 3:
        return None
    rgb = np.asarray(image.crop((left, top, right, bottom)).convert("RGB"), dtype=np.int16)
    gray = (rgb[:, :, 0] * 299 + rgb[:, :, 1] * 587 + rgb[:, :, 2] * 114) // 1000
    border = np.concatenate((gray[0, :], gray[-1, :], gray[:, 0], gray[:, -1]))
    background = int(np.median(border))
    contrast = np.abs(gray - background)
    peak = int(np.percentile(contrast, 99.5))
    if peak < 20:
        return None
    mask = contrast >= max(13, min(42, round(peak * 0.23)))
    ys, xs = np.nonzero(mask)
    if len(xs) < 5:
        return None
    return mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype("uint8")


@lru_cache(maxsize=512)
def _pil_font(path: str, size: int) -> Any:
    from PIL import ImageFont
    return ImageFont.truetype(path, size)


def _render_mask(text: str, candidate: dict[str, Any], target_height: int) -> Any | None:
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont

    try:
        face = _pil_font(str(candidate["path"]), 72)
        bbox = face.getbbox(text)
        if not bbox or bbox[2] <= bbox[0] or bbox[3] <= bbox[1]:
            return None
        size = max(8, min(512, round(72 * target_height / (bbox[3] - bbox[1]))))
        face = _pil_font(str(candidate["path"]), size)
        bbox = face.getbbox(text)
        width, height = bbox[2] - bbox[0], bbox[3] - bbox[1]
        if width <= 0 or height <= 0 or width > 4096:
            return None
        canvas = Image.new("L", (width, height), 0)
        ImageDraw.Draw(canvas).text((-bbox[0], -bbox[1]), text, font=face, fill=255)
        arr = np.asarray(canvas)
        mask = arr >= 90
        ys, xs = np.nonzero(mask)
        if len(xs) < 5:
            return None
        return mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype("uint8")
    except Exception:
        return None


def _cosine(left: Any, right: Any) -> float:
    import numpy as np

    a, b = left.astype("float32"), right.astype("float32")
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.dot(a, b) / denominator) if denominator else 0.0


def _similarity(source: Any, rendered: Any) -> float:
    import numpy as np
    from PIL import Image

    # Normalize glyph height only. Width stays intact so the match captures the
    # actual font's proportions and spacing rather than stretching a wrong face.
    height = 56
    src = np.asarray(Image.fromarray(source * 255).resize(
        (max(1, round(source.shape[1] * height / source.shape[0])), height), Image.Resampling.NEAREST)) > 127
    ref = np.asarray(Image.fromarray(rendered * 255).resize(
        (max(1, round(rendered.shape[1] * height / rendered.shape[0])), height), Image.Resampling.NEAREST)) > 127
    width = max(src.shape[1], ref.shape[1])
    if width > 1200:
        return 0.0
    a = np.zeros((height, width), dtype=bool); b = np.zeros((height, width), dtype=bool)
    a[:, :src.shape[1]] = src; b[:, :ref.shape[1]] = ref
    union = np.logical_or(a, b).sum()
    iou = float(np.logical_and(a, b).sum() / union) if union else 0.0
    columns = _cosine(a.sum(axis=0), b.sum(axis=0))
    rows = _cosine(a.sum(axis=1), b.sum(axis=1))
    proportion = math.exp(-abs(math.log(max(1, src.shape[1]) / max(1, ref.shape[1]))))
    return 0.48 * iou + 0.23 * columns + 0.14 * rows + 0.15 * proportion


def rank_font_candidates(image: Any, box: tuple[int, int, int, int], text: str,
                         catalog: list[dict[str, Any]], model_hints: list[dict[str, Any]] | None = None,
                         limit: int = 5) -> list[dict[str, Any]]:
    """Rank supported Latin/Cyrillic faces against a detected text crop."""
    if not text or len(re.sub(r"[^\w]", "", text, flags=re.UNICODE)) < 5 or any(ord(char) > 0x052f for char in text):
        return []
    source = _binary_crop(image, box)
    if source is None or source.shape[0] < 3:
        return []
    hints = {re.sub(r"[^a-z0-9]", "", str(item.get("value", "")).lower())
             for item in (model_hints or [])}
    ranked: list[dict[str, Any]] = []
    for candidate in catalog:
        if not _supports(candidate, text):
            continue
        rendered = _render_mask(text, candidate, source.shape[0])
        if rendered is None:
            continue
        visual_score = _similarity(source, rendered)
        score = visual_score
        family_key = re.sub(r"[^a-z0-9]", "", candidate["family"].lower())
        if family_key in hints:
            score = min(1.0, score + 0.015)
        if candidate["source"] == "document":
            # A font embedded elsewhere in this same PDF is valuable positive
            # evidence for scanned pages where rasterization/OCR shifts glyph
            # edges. Keep the raw visual score alongside this modest prior.
            score = min(1.0, score + 0.10)
        ranked.append({"family": candidate["family"], "value": f"document:{candidate['assetId']}"
                       if candidate["assetId"] else f"fontid:{candidate['family']}",
                       "confidence": score, "visualScore": visual_score,
                       "bold": candidate["bold"], "italic": candidate["italic"],
                       "source": candidate["source"], "assetId": candidate["assetId"]})
    ranked.sort(key=lambda item: item["confidence"], reverse=True)
    # Avoid returning the same family/style via separate aliases or embedded
    # duplicate subsets; keep both weights only when the style is distinct.
    unique: list[dict[str, Any]] = []
    seen: set[tuple[str, bool, bool]] = set()
    for candidate in ranked:
        key = (re.sub(r"[^a-z0-9]", "", candidate["family"].lower()), candidate["bold"], candidate["italic"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(candidate)
        if len(unique) >= limit:
            break
    return unique
