#!/usr/bin/env bash
set -euo pipefail

# Idempotent host installer. It checks the current machine first and installs
# only missing/mismatched components. Existing downloads are reused from pip/apt
# caches whenever possible. Set FORCE_INSTALL=1 only when a reinstall is desired.
FORCE_INSTALL="${FORCE_INSTALL:-0}"
PYTHON_BIN="${PYTHON_BIN:-python3.11}"
VENV_DIR="${VENV_DIR:-.venv}"
PIP_CACHE_DIR="${PIP_CACHE_DIR:-${HOME}/.cache/pdf-editor/pip}"
mkdir -p "$PIP_CACHE_DIR"

apt_is_installed() {
  dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q 'install ok installed'
}

apt_install_if_missing() {
  local missing=() pkg
  for pkg in "$@"; do
    if [[ "$FORCE_INSTALL" == "1" ]]; then
      missing+=("$pkg")
    elif apt_is_installed "$pkg"; then
      echo "[skip] apt: $pkg"
    else
      missing+=("$pkg")
    fi
  done
  ((${#missing[@]})) || return 0

  # Do not refresh package indexes on every run. Refresh only when no usable
  # package lists exist; if installation reports stale indexes, refresh once.
  local need_update=0
  if ! find /var/lib/apt/lists -type f -name '*Packages*' -print -quit 2>/dev/null | grep -q .; then
    need_update=1
  fi
  if ((need_update)); then
    echo "[install] apt index refresh"
    sudo apt-get update
  else
    echo "[skip] apt index refresh (existing package lists)"
  fi

  echo "[install] apt: ${missing[*]}"
  if ! sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing[@]}"; then
    echo "[retry] apt index refresh after stale/missing package metadata"
    sudo apt-get update
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing[@]}"
  fi
}

apt_install_if_missing \
  fontconfig fonts-dejavu-core fonts-noto-core fonts-noto-cjk fonts-liberation2 \
  fonts-lato fonts-crosextra-carlito fonts-urw-base35 libgl1 libglib2.0-0 libgomp1

if [[ -x "$VENV_DIR/bin/python" ]]; then
  echo "[skip] venv: $VENV_DIR"
else
  echo "[install] venv: $VENV_DIR"
  "$PYTHON_BIN" -m venv --system-site-packages "$VENV_DIR"
fi
source "$VENV_DIR/bin/activate"

python - <<'PY'
import importlib.metadata as md
from pathlib import Path
for line in Path('requirements.txt').read_text().splitlines():
    line=line.strip()
    if not line or line.startswith('#') or line.startswith('-'):
        continue
    name=line.split('==',1)[0].split('>=',1)[0].split('<=',1)[0].split('[',1)[0].strip()
    wanted=line.split('==',1)[1].strip() if '==' in line else None
    try:
        got=md.version(name)
        print(f"[skip] python: {name}=={got}" + (" (matches)" if not wanted or got == wanted else f" (required {wanted})"))
    except md.PackageNotFoundError:
        print(f"[missing] python: {line}")
PY

install_python_spec() {
  local spec="$1" name got
  name="${spec%%==*}"
  name="${name%%[*}"
  if [[ "$FORCE_INSTALL" == "1" ]]; then
    echo "[force] python: $spec"
    python -m pip install --cache-dir "$PIP_CACHE_DIR" "$spec"
    return
  fi
  if got="$(python -c "import importlib.metadata as m; print(m.version('$name'))" 2>/dev/null)"; then
    echo "[skip] python: $name==$got (already installed; no download)"
    return
  fi
  echo "[install] python: $spec"
  python -m pip install --cache-dir "$PIP_CACHE_DIR" "$spec"
}

install_python_spec_indexed() {
  local spec="$1" index="$2" name got
  name="${spec%%==*}"
  name="${name%%[*}"
  if [[ "$FORCE_INSTALL" == "1" ]]; then
    echo "[force] python: $spec"
    python -m pip install --cache-dir "$PIP_CACHE_DIR" "$spec" --index-url "$index"
    return
  fi
  if got="$(python -c "import importlib.metadata as m; print(m.version('$name'))" 2>/dev/null)"; then
    echo "[skip] python: $name==$got (already installed; no download)"
    return
  fi
  echo "[install] python: $spec"
  python -m pip install --cache-dir "$PIP_CACHE_DIR" "$spec" --index-url "$index"
}

install_python_spec_indexed 'paddlepaddle==3.3.0' 'https://www.paddlepaddle.org.cn/packages/stable/cpu/'
install_python_spec_indexed 'torch==2.11.0' 'https://download.pytorch.org/whl/cpu'

while IFS= read -r spec; do
  [[ -z "$spec" || "$spec" == \#* || "$spec" == -* ]] && continue
  install_python_spec "$spec"
done < requirements.txt

mkdir -p data
printf '\nInstallation check complete. Matching installed components were skipped; pip cache: %s\n' "$PIP_CACHE_DIR"
