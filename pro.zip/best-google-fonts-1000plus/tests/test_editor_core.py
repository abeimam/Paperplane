import os
import tempfile
import unittest
from pathlib import Path

import pymupdf as fitz
from fastapi.testclient import TestClient


class EditorCoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data_dir = tempfile.mkdtemp(prefix="pdf-editor-tests-")
        os.environ["DATA_DIR"] = cls.data_dir
        from app.main import app
        cls.client = TestClient(app)
        cls.font_path = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")

    def make_pdf(self) -> bytes:
        doc = fitz.open()
        page = doc.new_page(width=500, height=300)
        page.insert_text((60, 80), "Embedded Hello", fontsize=24, fontname="F0", fontfile=str(self.font_path))
        page.insert_text((60, 150), "Standard Hello", fontsize=24, fontname="helv")
        page.insert_text(
            fitz.Point(300, 200),
            "Rotated",
            fontsize=22,
            fontname="helv",
            morph=(fitz.Point(300, 200), fitz.Matrix(1, 1).prerotate(30)),
        )
        payload = doc.tobytes()
        doc.close()
        return payload

    def open_model(self):
        response = self.client.post("/api/documents", files={"file": ("test.pdf", self.make_pdf(), "application/pdf")})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()


    def test_loading_a_new_pdf_removes_the_previous_document_data(self):
        first = self.open_model()
        first_dir = Path(self.data_dir) / first["id"]
        self.assertTrue((first_dir / "original.pdf").exists())

        second = self.open_model()
        second_dir = Path(self.data_dir) / second["id"]
        self.assertTrue(second_dir.exists())
        self.assertFalse(first_dir.exists(), "previous PDF data must be deleted when a new PDF is loaded")

        document_dirs = [p for p in Path(self.data_dir).iterdir() if p.is_dir() and len(p.name) == 32]
        self.assertEqual([p.name for p in document_dirs], [second["id"]])

        stale_response = self.client.get(f"/api/documents/{first['id']}/pages/0/image")
        self.assertEqual(stale_response.status_code, 404)

    def test_native_font_metadata_and_rotation_are_exact(self):
        model = self.open_model()
        embedded = next(item for item in model["objects"] if item["text"] == "Embedded Hello")
        rotated = next(item for item in model["objects"] if item["text"] == "Rotated")
        self.assertEqual(embedded["font"], "DejaVuSans")
        self.assertTrue(embedded["fontAsset"])
        self.assertEqual(embedded["fontCandidates"][0]["source"], "exact")
        self.assertAlmostEqual(rotated["rotation"], 30.0, places=2)

    def test_exact_font_is_reused_on_replacement_and_rotation(self):
        model = self.open_model()
        target = next(item for item in model["objects"] if item["text"] == "Embedded Hello")
        target["text"] = "Embedded Changed"
        target["rotation"] = 37
        target["y"] = 100
        response = self.client.post(f"/api/documents/{model['id']}/export", json={"objects": model["objects"]})
        self.assertEqual(response.status_code, 200, response.text)
        exported = fitz.open(stream=response.content, filetype="pdf")
        self.assertTrue(any(font[2] == "Type0" and "DejaVu Sans" in font[3] for font in exported[0].get_fonts(full=True)))
        found = None
        for block in exported[0].get_text("rawdict").get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    text = "".join(char.get("c", "") for char in span.get("chars", []))
                    if text == "Embedded Changed":
                        found = (span["font"], line["dir"])
        exported.close()
        self.assertIsNotNone(found)
        self.assertIn("DejaVu", found[0])
        self.assertAlmostEqual(found[1][0], 0.7986, places=3)
        self.assertAlmostEqual(found[1][1], -0.6018, places=3)


    def test_unembedded_computer_modern_font_resolves_from_bundled_type1_pack(self):
        from app.main import EditObject, insertion_font, font_file_for_family

        bundled = font_file_for_family("CMBX12", False, False, "CMBX12 replacement")
        self.assertIsNotNone(bundled)
        self.assertEqual(bundled.suffix.lower(), ".pfb")
        edit = EditObject(
            id="cmbx", page=0, text="CMBX12 replacement", x=60, y=220, width=180, height=24,
            fontSize=12, color="#000000", fontFamily="original", bold=False, italic=False,
        )
        name, path = insertion_font(
            edit,
            {"source": "native", "font": "CMBX12", "bold": False, "italic": False, "fontFamilyHint": "serif"},
            Path(__file__).resolve().parents[1],
        )
        self.assertEqual(path, str(bundled))
        self.assertEqual(name, "CMBX12")

    def test_standard_pdf_font_is_kept_exact(self):
        model = self.open_model()
        target = next(item for item in model["objects"] if item["text"] == "Standard Hello")
        target["text"] = "Standard Changed"
        response = self.client.post(f"/api/documents/{model['id']}/export", json={"objects": model["objects"]})
        self.assertEqual(response.status_code, 200, response.text)
        exported = fitz.open(stream=response.content, filetype="pdf")
        fonts = exported[0].get_fonts(full=True)
        self.assertTrue(any(font[3] == "Helvetica" for font in fonts))
        exported.close()


if __name__ == "__main__":
    unittest.main()

def test_build_is_idempotent_and_reuses_download_caches():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    docker = (root / "Dockerfile").read_text()
    installer = (root / "scripts" / "install.sh").read_text()
    assert "--upgrade pip" not in docker
    assert "FORCE_INSTALL" in installer
    assert "dpkg-query" in installer
    assert "importlib.metadata" in docker
    assert "type=cache,target=/root/.cache/pip" in docker
    assert "type=cache,target=/var/cache/apt" in docker
    assert "type=cache,target=/var/lib/apt/lists" in docker
    assert "apt-get update" in installer
    assert "apt index refresh" in installer
