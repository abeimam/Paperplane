from pathlib import Path
import json


def test_google_catalog_filters_to_latin(tmp_path, monkeypatch):
    from app import google_fonts
    google_fonts.CACHE_ROOT = tmp_path
    google_fonts.CATALOG_PATH = tmp_path / 'catalog.json'

    payload = {
        'familyMetadataList': [
            {'family': 'Alpha Sans', 'subsets': ['latin']},
            {'family': 'Beta Arabic', 'subsets': ['arabic']},
            {'family': 'Gamma', 'subsets': ['latin', 'latin-ext']},
        ]
    }
    def fake_open(request, timeout=0):
        class R:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self): return json.dumps(payload).encode()
        return R()
    monkeypatch.setattr(google_fonts, 'urlopen', fake_open)
    assert google_fonts.refresh_catalog(True) == ['Alpha Sans', 'Gamma']


def test_google_catalog_supports_1000_families(tmp_path, monkeypatch):
    from app import google_fonts
    google_fonts.CACHE_ROOT = tmp_path
    google_fonts.CATALOG_PATH = tmp_path / 'catalog.json'
    families = [{'family': f'English Font {i:04d}', 'subsets': ['latin']} for i in range(1001)]
    payload = {'familyMetadataList': families}
    def fake_open(request, timeout=0):
        class R:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self): return json.dumps(payload).encode()
        return R()
    monkeypatch.setattr(google_fonts, 'urlopen', fake_open)
    result = google_fonts.refresh_catalog(True)
    assert len(result) == 1001
    assert result[0] == 'English Font 0000'


def test_google_css_urls_are_parsed(monkeypatch):
    from app import google_fonts
    css = '/* latin */\n@font-face { src: url(https://fonts.gstatic.com/s/test.woff2) format(\'woff2\'); }'
    class R:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self): return css.encode()
    monkeypatch.setattr(google_fonts, 'urlopen', lambda *args, **kwargs: R())
    assert google_fonts._css_source_urls('Test Font', False, False) == ['https://fonts.gstatic.com/s/test.woff2']
